# Dzulkifli-DK
BOT PROTECT PY3 ANTI JS DK-BOT LINE🐦FIXS UPDATE:JUM'AT 7 DESEMBER 2018
------
GET TOKEN :
------
- `Google Chrome`
- `http://101.255.95.249:6969`
-
Cara Install Bot :
------
HEADER CHROME

C9 SERVER/ VPS :
- `sudo apt-get update -y`
- `sudo apt-get install git -y`
- `sudo apt-get install python3-pip -y`
- `sudo pip3 install rsa`
- `sudo pip3 install thrift==0.11.0`
- `sudo pip3 install requests`
- `sudo pip3 install pytz`
- `sudo pip3 install bs4`
- `sudo pip3 install gtts`
- `sudo pip3 install googletrans`
- `sudo pip3 install humanfriendly`
- `sudo pip3 install goslate`
- `sudo pip3 install pafy`
- `sudo pip3 install wikipedia`
- `sudo pip3 install tweepy`
- `sudo pip3 install youtube_dl`
- `git clone  https://github.com/Dzulkifli1/DKBOT-ANTIJS.git
- `cd ajs2`
- `python Kifli12.py`

INSTALL Di TERMUX :
- `pkg update`
- `pkg install git`
- `pkg install python3-pip`
- `pip3 install rsa`
- `pip3 install thrift==0.11.0`
- `pip3 install requests`
- `pip3 install bs4`
- `pip3 install gtts`
- `pip3 install beautifulsoup`
- `pip3 install googletrans`
- `pip3 install pafy`
- `pip3 install humanfriendly`
- `pip3 install goslate`
- `pip3 install wikipedia`
- `pip3 install youtube_dl`
- `pip3 install tweepy`
- `git clone https://github.com/Dzulkifli1/DKBOT-ANTIJS.git
- `cd DKBOT-ANTIJS
- `python3 kifli5.py`

Cara Menjalankan Bot Kembali :
------
Di C9 :
- `cd DKBOT-ANTIJS
- `python3 kifli5.py

Di Termux :
- `cd DKBOT-ANTIJS`
- `python3 kifli12.py`


EDITOR BY DZULKIFLI
------
- `Add My ID LINE :http://line.me/ti/p/~reza.p.i.p pakai titik ya 😂`
#cuma saran bukan menggurui 😅
#aku juga masih pekok kuadrat😊

Thx To : ALLOH SWT & All
------
- `SALAM HORMAT BUAT PARA MASTAH SEMUANYA 😅 `


